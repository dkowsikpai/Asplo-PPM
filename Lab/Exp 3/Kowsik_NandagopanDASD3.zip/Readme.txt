------------README--------------
Login to the MySQL Database Server using your credential. If It is CLI
use the command
mysql -u <username> -p
Enter the password

----------Use Database open_ppm----------
SQL Commands are in the relation.sql in the same directory from this file was downloaded
Use source command to read and execute the command in SQL
For Eg:
msql> source /home/<path to directory>/relation.sql

Wait until the process completes

Tables will be displayed in the order of following questions(queries)

1. Select name of project manager from the database
2. Select Customer Name from the database corresponding to the project name
3. Select Name of technologies used in project. Display only the name of the project and name of technology
4. Select the name of the project, name of consultant and effort they spent on the project
5. Display the names of consultant, email, phone number
6. Select the name of consultants, name of designation ad the grade
7. Select the name of customer, and alternate contact phone number from the project
