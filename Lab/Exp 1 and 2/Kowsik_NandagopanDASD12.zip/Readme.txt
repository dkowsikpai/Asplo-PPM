------------README--------------
Login to the MySQL Database Server using your credential. If It is CLI
use the command
mysql -u <username> -p
Enter the password

----------Creating Database and Tables----------
SQL Commands are in the database.sql in the same directory from this file was d$
Use source command to read and execute the command in SQL
For Eg:
msql> source /home/<path to directory>/database.sql

Wait until the process completes

Use
show databases;
command to see the database named open_ppm

------------Insert Data to database-------------
SQL Commands are in the dummy_data.sql in the same directory from this file was d$
Use source command to read and execute the command in SQL
For Eg:
msql> source /home/<path to directory>/dummy_data.sql

Wait until the process completes

use show tables to see the tables

