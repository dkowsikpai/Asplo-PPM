------------README--------------
Login to the MySQL Database Server using your credential. If It is CLI
use the command
mysql -u <username> -p
Enter the password

----------Built-in Functions in database----------
SQL Commands are in the func.sql in the same directory from this file was downloaded
Use source command to read and execute the command in SQL
For Eg:
msql> source /home/<path to directory>/func.sql

Wait until the process completes

It will show the tables in the order
1. Select the consultants table and output string lenth of presentAddress and presentAddress
2. Select Consultants and print the name in the format:- Name (DESIGNATION)
3. Print Value of PI
4. Select Project Transactions table and display the project name and entries of percentage completed of each resource. Percentage completed must be rounded of to one decimal
5. Select Project Transactions table and display the project name and entries of percentage completed of each resource. Perentage completed must be to nearest integer (not decimal)
6. Display the minimum and maximuam in project transaction
7. Display the current date in console
8. Select Project table and display the title, project start date. Date must be in format Day Date. Month must be displayed in name format
9. Display the number of days between start date and finish date for each project
10. Display the date which is 10 days before finish date in specific format.
11. Display the status in text format corresponding to the integer format for each projects
12. Display the user_status in text format. Use IF to convert ot text
13. Display the details of the current connection

------------Aggregate functions-------------
SQL Commands are in the agg.sql in the same directory from this file was downloaded
Use source command to read and execute the command in SQL
For Eg:
msql> source /home/<path to directory>/agg.sql

Wait until the process completes

It will show all the following functions in one table
1. AVG
2. COUNT
3. SUM
4. STD
5. VARIANCE

Display the minimum and maximuam in project transaction
