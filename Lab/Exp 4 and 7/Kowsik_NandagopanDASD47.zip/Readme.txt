------------README--------------
Login to the MySQL Database Server using your credential. If It is CLI
use the command
mysql -u <username> -p
Enter the password

----------Creating Constraints and Trying to Override----------
SQL Commands are in the constraints.sql in the same directory from this file was downloaded
Use source command to read and execute the command in SQL
For Eg:
msql> source /home/<path to directory>/constraints.sql

Wait until the process completes
This SQL will different outputs. The order and description are provided in the SQL file

------------Create different Views for table-------------
SQL Commands are in the views.sql in the same directory from this file was downloaded
Use source command to read and execute the command in SQL
For Eg:
msql> source /home/<path to directory>/views.sql

Wait until the process completes
This SQL will different outputs. The order and description are provided in the SQL file

